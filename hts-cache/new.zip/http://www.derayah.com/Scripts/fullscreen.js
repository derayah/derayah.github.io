
window.addEventListener('load', function() {
    setTimeout(scrollTo, 0, 0, 1);
}, false);
